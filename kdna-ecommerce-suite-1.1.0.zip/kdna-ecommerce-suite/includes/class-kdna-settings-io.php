<?php
/**
 * Settings Import / Export.
 *
 * Exports the plugin's settings to a JSON file and imports them again,
 * so a configured site can be copied to another site.
 */
defined( 'ABSPATH' ) || exit;

class KDNA_Settings_IO {

    const EXPORT_ACTION = 'kdna_export_settings';
    const IMPORT_ACTION = 'kdna_import_settings';
    const NOTICE_KEY    = 'kdna_settings_io_notice_';
    const MAX_FILE_SIZE = 2097152; // 2 MB.

    /** Australia Post shipping method settings (global, not per-zone). */
    const AUSPOST_OPTION = 'woocommerce_kdna_australia_post_settings';

    /**
     * Site-specific keys that keep the destination site's values on import.
     * The WooCommerce email template selection (kdna_woo_email_template_id)
     * is never exported, so it always stays as it is on the destination.
     */
    const KEEP_DESTINATION_KEYS = [
        'kdna_invoice_settings'       => [ 'logo_id' ],
        'kdna_automations_settings'   => [ 'communication_preferences_page_id', 'communication_signup_page_id' ],
        'kdna_smart_coupons_settings' => [ 'cashback_template_coupon' ],
    ];

    public function __construct() {
        add_action( 'admin_post_' . self::EXPORT_ACTION, [ $this, 'handle_export' ] );
        add_action( 'admin_post_' . self::IMPORT_ACTION, [ $this, 'handle_import' ] );
    }

    /**
     * Exportable sections: section key => [ label, option name ].
     */
    public static function get_sections() {
        return [
            'modules'         => [ __( 'Enabled modules', 'kdna-ecommerce' ), 'kdna_ecommerce_modules' ],
            'points'          => [ __( 'Points & Rewards', 'kdna-ecommerce' ), 'kdna_points_settings' ],
            'reviews'         => [ __( 'Reviews', 'kdna-ecommerce' ), 'kdna_reviews_settings' ],
            'related'         => [ __( 'Related Products', 'kdna-ecommerce' ), 'kdna_related_settings' ],
            'sequential'      => [ __( 'Sequential Orders', 'kdna-ecommerce' ), 'kdna_sequential_settings' ],
            'invoice'         => [ __( 'Tax Invoice', 'kdna-ecommerce' ), 'kdna_invoice_settings' ],
            'smart_coupons'   => [ __( 'Smart Coupons', 'kdna-ecommerce' ), 'kdna_smart_coupons_settings' ],
            'automations'     => [ __( 'Automations', 'kdna-ecommerce' ), 'kdna_automations_settings' ],
            'followup_emails' => [ __( 'Emails', 'kdna-ecommerce' ), 'kdna_followup_emails_settings' ],
            'australia_post'  => [ __( 'Australia Post', 'kdna-ecommerce' ), self::AUSPOST_OPTION ],
        ];
    }

    // ===================================================================
    // Export
    // ===================================================================

    public function handle_export() {
        check_admin_referer( self::EXPORT_ACTION );

        if ( ! current_user_can( 'manage_woocommerce' ) ) {
            wp_die( esc_html__( 'You do not have permission to export settings.', 'kdna-ecommerce' ), 403 );
        }

        $settings = [];
        foreach ( self::get_sections() as $section ) {
            $value = get_option( $section[1], null );
            if ( null !== $value && false !== $value ) {
                $settings[ $section[1] ] = $value;
            }
        }

        $data = [
            'plugin'      => 'kdna-ecommerce-suite',
            'version'     => KDNA_ECOMMERCE_VERSION,
            'exported_at' => gmdate( 'c' ),
            'site_url'    => home_url(),
            'settings'    => $settings,
        ];

        $host     = sanitize_file_name( (string) wp_parse_url( home_url(), PHP_URL_HOST ) );
        $filename = 'kdna-ecommerce-settings-' . ( $host ? $host . '-' : '' ) . gmdate( 'Y-m-d' ) . '.json';

        nocache_headers();
        header( 'Content-Type: application/json; charset=utf-8' );
        header( 'Content-Disposition: attachment; filename="' . $filename . '"' );
        echo wp_json_encode( $data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
        exit;
    }

    // ===================================================================
    // Import
    // ===================================================================

    public function handle_import() {
        check_admin_referer( self::IMPORT_ACTION );

        if ( ! current_user_can( 'manage_woocommerce' ) ) {
            wp_die( esc_html__( 'You do not have permission to import settings.', 'kdna-ecommerce' ), 403 );
        }

        $file = $_FILES['kdna_settings_file'] ?? null;
        if ( ! $file || ! isset( $file['error'] ) || is_array( $file['error'] ) || UPLOAD_ERR_OK !== $file['error'] || ! is_uploaded_file( $file['tmp_name'] ) ) {
            $this->redirect_with_notice( 'error', __( 'Please choose a settings file to import.', 'kdna-ecommerce' ) );
        }

        if ( $file['size'] > self::MAX_FILE_SIZE ) {
            $this->redirect_with_notice( 'error', __( 'The settings file is too large.', 'kdna-ecommerce' ) );
        }

        $data = json_decode( (string) file_get_contents( $file['tmp_name'] ), true );
        if ( ! is_array( $data ) || ( $data['plugin'] ?? '' ) !== 'kdna-ecommerce-suite' || ! isset( $data['settings'] ) || ! is_array( $data['settings'] ) ) {
            $this->redirect_with_notice( 'error', __( 'This is not a valid E-commerce Suite settings file.', 'kdna-ecommerce' ) );
        }

        $chosen = isset( $_POST['kdna_sections'] ) && is_array( $_POST['kdna_sections'] )
            ? array_map( 'sanitize_key', wp_unslash( $_POST['kdna_sections'] ) )
            : [];

        if ( empty( $chosen ) ) {
            $this->redirect_with_notice( 'error', __( 'Choose at least one section to import.', 'kdna-ecommerce' ) );
        }

        $imported = [];
        $skipped  = [];

        foreach ( self::get_sections() as $key => $section ) {
            if ( ! in_array( $key, $chosen, true ) ) {
                continue;
            }

            list( $label, $option ) = $section;

            if ( ! isset( $data['settings'][ $option ] ) || ! is_array( $data['settings'][ $option ] ) ) {
                $skipped[] = $label;
                continue;
            }

            $value = $data['settings'][ $option ];

            // Keep the destination site's values for site-specific IDs.
            if ( isset( self::KEEP_DESTINATION_KEYS[ $option ] ) ) {
                $current = get_option( $option, [] );
                foreach ( self::KEEP_DESTINATION_KEYS[ $option ] as $site_key ) {
                    if ( is_array( $current ) && isset( $current[ $site_key ] ) ) {
                        $value[ $site_key ] = $current[ $site_key ];
                    } else {
                        unset( $value[ $site_key ] );
                    }
                }
            }

            if ( self::AUSPOST_OPTION === $option ) {
                // No registered sanitizer for the shipping method's option.
                $value = map_deep( $value, 'sanitize_text_field' );
            }

            // update_option() runs the option's registered sanitize callback.
            update_option( $option, $value );
            $imported[] = $label;
        }

        if ( empty( $imported ) ) {
            $this->redirect_with_notice( 'error', __( 'Nothing was imported. The file has no settings for the chosen sections.', 'kdna-ecommerce' ) );
        }

        /* translators: %s: comma-separated list of settings sections. */
        $message = sprintf( __( 'Settings imported: %s.', 'kdna-ecommerce' ), implode( ', ', $imported ) );
        if ( $skipped ) {
            /* translators: %s: comma-separated list of settings sections. */
            $message .= ' ' . sprintf( __( 'Not in the file: %s.', 'kdna-ecommerce' ), implode( ', ', $skipped ) );
        }

        $this->redirect_with_notice( 'success', $message );
    }

    private function redirect_with_notice( $type, $message ) {
        set_transient( self::NOTICE_KEY . get_current_user_id(), [
            'type'    => $type,
            'message' => $message,
        ], 5 * MINUTE_IN_SECONDS );

        wp_safe_redirect( admin_url( 'admin.php?page=kdna-ecommerce&tab=import_export' ) );
        exit;
    }

    // ===================================================================
    // Tab
    // ===================================================================

    public static function render_tab() {
        $notice_key = self::NOTICE_KEY . get_current_user_id();
        $notice     = get_transient( $notice_key );
        if ( $notice ) {
            delete_transient( $notice_key );
        }
        ?>
        <?php if ( is_array( $notice ) && ! empty( $notice['message'] ) ) : ?>
            <div class="notice notice-<?php echo 'success' === $notice['type'] ? 'success' : 'error'; ?> inline"><p><?php echo esc_html( $notice['message'] ); ?></p></div>
        <?php endif; ?>

        <h2><?php esc_html_e( 'Export Settings', 'kdna-ecommerce' ); ?></h2>
        <p class="description"><?php esc_html_e( 'Download all E-commerce Suite settings as a JSON file. Templates, workflows, coupons and other content are not included.', 'kdna-ecommerce' ); ?></p>
        <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
            <input type="hidden" name="action" value="<?php echo esc_attr( self::EXPORT_ACTION ); ?>">
            <?php wp_nonce_field( self::EXPORT_ACTION ); ?>
            <?php submit_button( __( 'Download Settings File', 'kdna-ecommerce' ), 'secondary', 'submit', true ); ?>
        </form>

        <hr>

        <h2><?php esc_html_e( 'Import Settings', 'kdna-ecommerce' ); ?></h2>
        <p class="description"><?php esc_html_e( 'Upload a settings file exported from this plugin. The chosen sections replace the current settings. The invoice logo, the WooCommerce email template and per-zone Australia Post settings are not changed.', 'kdna-ecommerce' ); ?></p>
        <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" enctype="multipart/form-data">
            <input type="hidden" name="action" value="<?php echo esc_attr( self::IMPORT_ACTION ); ?>">
            <?php wp_nonce_field( self::IMPORT_ACTION ); ?>
            <table class="form-table">
                <tr>
                    <th scope="row"><label for="kdna_settings_file"><?php esc_html_e( 'Settings file', 'kdna-ecommerce' ); ?></label></th>
                    <td><input type="file" name="kdna_settings_file" id="kdna_settings_file" accept=".json,application/json" required></td>
                </tr>
                <tr>
                    <th scope="row"><?php esc_html_e( 'Sections to import', 'kdna-ecommerce' ); ?></th>
                    <td>
                        <fieldset>
                            <?php foreach ( self::get_sections() as $key => $section ) : ?>
                                <label style="display:block;margin-bottom:6px;">
                                    <input type="checkbox" name="kdna_sections[]" value="<?php echo esc_attr( $key ); ?>" checked>
                                    <?php echo esc_html( $section[0] ); ?>
                                </label>
                            <?php endforeach; ?>
                        </fieldset>
                    </td>
                </tr>
            </table>
            <?php submit_button( __( 'Import Settings', 'kdna-ecommerce' ) ); ?>
        </form>
        <?php
    }
}
